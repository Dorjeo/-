(function () {
  function getApp() {
    return document.getElementById("app") || document.getElementById("pageContent");
  }

  function normalizeUrl(href) {
    return new URL(href, window.location.href).href;
  }

  function loadPage(href, push = true) {
    const app = document.getElementById("app");

    if (!app) {
      window.location.href = href;
      return;
    }

    const fullUrl = normalizeUrl(href);

    fetch(fullUrl)
      .then((res) => {
        if (!res.ok) throw new Error("Page not found");
        return res.text();
      })
      .then((html) => {
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, "text/html");

        const newContent =
          doc.querySelector("#pageContent") ||
          doc.querySelector("main") ||
          doc.querySelector("section");

        if (!newContent) {
          window.location.href = href;
          return;
        }

        app.innerHTML = newContent.innerHTML;

        if (push) {
          history.pushState({ url: fullUrl }, "", fullUrl);
        }

        runPageScripts(fullUrl);
        window.scrollTo(0, 0);
      })
      .catch(() => {
        window.location.href = href;
      });
  }

  function runPageScripts(url) {
    if (url.includes("/pages/user/novels.html")) {
      reloadScript("/js/user-novels.js");
    }

    if (url.includes("/pages/user/detail.html")) {
      reloadScript("/js/detail.js");
    }

    if (url.includes("/pages/user/read.html")) {
      reloadScript("/js/read.js");
    }

    if (url.includes("/pages/user/profile.html")) {
      reloadScript("/js/profile.js");
    }

    if (url.includes("/pages/user/favorites.html")) {
      reloadScript("/js/favorites.js");
    }

    if (url.includes("/pages/user/new-novels.html")) {
      reloadScript("/js/new-novels.js");
    }

    if (url.includes("/pages/user/popular.html")) {
      reloadScript("/js/popular.js");
    }

    if (url.includes("/pages/user/transactions.html")) {
      reloadScript("/js/transactions.js");
    }
  }

  function reloadScript(src) {
    const old = document.querySelector(`script[data-spa-src="${src}"]`);
    if (old) old.remove();

    const script = document.createElement("script");
    script.src = src + "?v=" + Date.now();
    script.dataset.spaSrc = src;
    document.body.appendChild(script);
  }

  document.addEventListener("click", function (e) {
    const link = e.target.closest("a[data-spa]");
    if (!link) return;

    const href = link.getAttribute("href");
    if (!href || href.startsWith("#") || href.startsWith("http")) return;

    e.preventDefault();
    loadPage(href, true);
  });

  window.addEventListener("popstate", function () {
    window.location.reload();
  });
})();